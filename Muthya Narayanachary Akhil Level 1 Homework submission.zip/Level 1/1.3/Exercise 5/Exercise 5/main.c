//
//  main.c
//  Exercise 5
//
//  Created by Akhil Muthya Narayanachary on 13/8/25.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int pre_increment = 0, post_increment = 0;
    printf("This is what happens when you pre_increment while printing: %d\n", ++pre_increment);
    printf("This is what happens when you post_increment while printing: %d\n", post_increment++);
    return 0;
}

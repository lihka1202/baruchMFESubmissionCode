//
//  main.c
//  Exercise 4
//
//  Created by Akhil Muthya Narayanachary on 13/8/25.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int married_or_not;
    
    // take the input
    printf("Please enter the married or not status: ");
    scanf("%d", &married_or_not);
    
    // build the output
    printf("The final status is: %s\n", married_or_not ? "married" : "not married");
    
    return 0;
}

#include <stdio.h>
int main()
{
    int x=2;
    int y;
    int z;
    
    // This will evaluate to 10
    x*=3+2;
    printf("x=%d\n", x);
    
    // This will evaluate to 40
    x*=y=z=4;
    printf("x=%d\n", x);
    
    // This will evaluate to 1
    x=y==z;
    printf("x=%d\n", x);
    return 0;
}

#include <stdio.h>
int main()
{
    int x=1;
    int y=1;
    int z=1;
    x+=y+=x;
    
    // x = 3, y = 2, z = 1
    printf("%d\n\n", (x<y)?y:x); // Number 1 ==> 3
    printf("%d\n", (x<y)?x++:y++); // Number 2 ==> 2
    
    // x = 3, y = 3, z = 1
    printf("%d\n", x); // Number 3 ==> 3
    printf("%d\n", y); // Number 4 ==> 3
    return 0;
}

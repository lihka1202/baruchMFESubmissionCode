//
//  main.c
//  Exercise 2
//
//  Created by Akhil Muthya Narayanachary on 12/8/25.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    float base = 0;
    float height = 0;
    
    // Get the base
    printf("Please enter the base: ");
    scanf("%f",&base);
    
    // Get the height
    printf("Please enter the height: ");
    scanf("%f", &height);
    
    // store the output
    double area = 0.5 * base * height;
    printf("This is the final area: %f\n", area);
    return 0;
}

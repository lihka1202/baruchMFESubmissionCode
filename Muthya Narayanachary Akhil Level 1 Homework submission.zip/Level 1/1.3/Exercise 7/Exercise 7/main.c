#include <stdio.h>
int main()
{
    int number, n;
    printf("Please enter the number you wish to multiply: ");
    scanf("%d", &number);
    printf("Please enter the power of 2 with which you would like to multiply: ");
    scanf("%d", &n);
    
    int answer = number * (1<<n);
    printf("This is the answer: %d\n", answer);
}

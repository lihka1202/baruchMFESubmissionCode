//
//  main.c
//  Exercise 6
//
//  Created by Akhil Muthya Narayanachary on 13/8/25.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n;
    printf("Enter the number: ");
    scanf("%d", &n);
    int holder = n >> 2;
    char *answer = n >= 0 ? "arithmetic or logical" : (holder < 0 ? "arithmetic" : "logical");
    printf("This is a case of %s shift\n", answer);
    
}

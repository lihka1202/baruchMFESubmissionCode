//
//  main.c
//  Exercise 1
//
//  Created by Akhil Muthya Narayanachary on 12/8/25.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    char *holder = "My first C-program\nis a fact!\nGood, isn't it?";
    printf("%s", holder);
    return 0;
}

//
//  Print.c
//  Exercise 3
//
//  Created by Akhil Muthya Narayanachary on 20/8/25.
//
#include<stdio.h>

void print(int n) {
    printf("This is the number from the other file: %d\n", n);
}

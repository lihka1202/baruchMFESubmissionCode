//
//  Main.c
//  Exercise 3
//
//  Created by Akhil Muthya Narayanachary on 20/8/25.
//


#include <stdio.h>

// Forward declaration of the function in Print.c
void print(int i);

int main(void) {
    int i = 5;
    print(i);
    return 0;
}

//
//  Macros.c
//  Exercise 2
//
//  Created by Akhil Muthya Narayanachary on 15/9/25.
//

#include "Defs.h"
int main(int argc, const char * argv[]) {
    PRINT1(MAX2(3, 4));
    PRINT1(MAX3(3, 4, 5));
    return 0;
}

//
//  Macros.c
//  Exercise 1
//
//  Created by Akhil Muthya Narayanachary on 15/9/25.
//

// Include Defs.h
#include "Defs.h"

int main(int argc, const char * argv[]) {
    // Use the print macros defined in the other file
    PRINT1(5);
    PRINT2(3, 4);
    return 0;
}
